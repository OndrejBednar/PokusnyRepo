﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TestDictionary
{
    class DictionaryItem
    {
        /* třída spravuje položky česko-anglického slovníku
         obsahuje:
         * english = anglické slovo, je možné získat jeho hodnotu mimo třídu
         * czech = české slovo, je možné získat jeho hodnotu mimo třídu
         * wanted = počet, kolikrát bylo slovo vyhledáno, mimo třídu je možné získat jeho hodnotu, nastavit ji a zvýšit ji o jedna
         
         * parametrický konstruktor, který nastavuje "wanted" na 0
         * třídu je možné vypsat přes Console.Writeline
         * je také možné získat rozdíl délek mezi českým a anglickým výrazem (ve výpisu se pak objevuje "cs", "en" nebo "=" podle toho, co je kratší)
        */
    }
}
